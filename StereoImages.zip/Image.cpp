#include "Image.h"

extern SDL_Renderer* renderer;
extern SDL_Window* window;

void Image::Load(std::string filename) {
	Cleanup();
	name = filename;
	surf = IMG_Load(filename.c_str());
	if (surf) {
		if (surf->format->format != SDL_PIXELFORMAT_RGBA32) {
			SDL_Surface* surf_buf = SDL_ConvertSurfaceFormat(surf, SDL_PIXELFORMAT_RGBA32, 0);
			SDL_FreeSurface(surf);
			surf = surf_buf;
		}
		texture = SDL_CreateTextureFromSurface(renderer, surf);
	}
	else {
		Cleanup();
	}
}

void Image::SetFromSurface(SDL_Surface* set_surf, std::string set_name) {
	if (set_surf) {
		Cleanup();
		name = set_name;
		surf = set_surf;
		texture = SDL_CreateTextureFromSurface(renderer, surf);
	}
}

void Image::Disp(int x, int y, int w, int h) {
	if (texture) {
		disprect.x = x;
		disprect.y = y;
		disprect.w = w;
		disprect.h = h;
		SDL_RenderCopy(renderer, texture, nullptr, &disprect);
	}
}

void Image::Cleanup() {
	if (texture) {
		SDL_DestroyTexture(texture);
		texture = nullptr;
	}
	if (surf) {
		SDL_FreeSurface(surf);
		surf = nullptr;
	}
	name = "";
}