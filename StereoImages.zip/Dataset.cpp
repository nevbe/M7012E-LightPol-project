#include "Dataset.h"
#include <cmath>

void Dataset::Load(std::string dataset_name) {
	std::string name = dataset_name;
	dataset_name = "data/" + name + "/";
	L.Load(dataset_name + "im0.png");
	R.Load(dataset_name + "im1.png");
	SetEdges();
}

void Dataset::Conv(unsigned char* dst, unsigned char* src, unsigned char channels, float* kernel, unsigned char kernelsize, unsigned short int width, unsigned short int height) {
	if (dst && src && kernel && kernelsize > 1 && width > 1 && height > 1 && channels > 0) {
		for (int a = 0; a < height; a++) {
			for (int b = 0; b < width; b++) {
				for (int ch = 0; ch < channels; ch++) {
					float val = 0;
					for (int aa = 0; aa < kernelsize; aa++) {
						for (int bb = 0; bb < kernelsize; bb++) {
							int aq = a + aa - (kernelsize - 1) / 2;
							int bq = b + bb - (kernelsize - 1) / 2;
							if (aq >= 0 && aq < height && bq >= 0 && bq < width) {
								val += kernel[aa * kernelsize + bb] * (float)src[channels * (aq * width + bq) + ch];
							}
						}
					}
					val = val / kernelsize / kernelsize;
					if (val > 255) {
						val = 255;
					}
					if (val < 0) {
						val = 0;
					}
					dst[channels * (a * width + b) + ch] = val;
				}
			}
		}
	}
}

void Dataset::Compute(unsigned char* dst, unsigned char* src1, unsigned char* src2, unsigned char channels, char operation, unsigned short int width, unsigned short int height) {
	if (dst && src1 && src2 && channels > 0 && width > 0 && height > 0) {
		if (operation == '+') {
			for (int a = 0; a < height; a++) {
				for (int b = 0; b < width; b++) {
					for (int ch = 0; ch < channels; ch++) {
						int val = (int)src1[channels * (a * width + b) + ch] + (int)src2[channels * (a * width + b) + ch];
						if (val > 255) {
							val = 255;
						}
						dst[channels * (a * width + b) + ch] = val;
					}
				}
			}
		}
		else if (operation == '-') {
			for (int a = 0; a < height; a++) {
				for (int b = 0; b < width; b++) {
					for (int ch = 0; ch < channels; ch++) {
						int val = (int)src1[channels * (a * width + b) + ch] - (int)src2[channels * (a * width + b) + ch];
						if (val < 0) {
							val = 0;
						}
						dst[channels * (a * width + b) + ch] = val;
					}
				}
			}
		}
		else if (operation == '*') {
			for (int a = 0; a < height; a++) {
				for (int b = 0; b < width; b++) {
					for (int ch = 0; ch < channels; ch++) {
						int val = (int)src1[channels * (a * width + b) + ch] * (int)src2[channels * (a * width + b) + ch];
						if (val > 255) {
							val = 255;
						}
						dst[channels * (a * width + b) + ch] = val;
					}
				}
			}
		}
		else if (operation == '/') {
			for (int a = 0; a < height; a++) {
				for (int b = 0; b < width; b++) {
					for (int ch = 0; ch < channels; ch++) {
						float val = (float)src1[channels * (a * width + b) + ch] * (float)src2[channels * (a * width + b) + ch];
						//no failchecking needed
						dst[channels * (a * width + b) + ch] = val;
					}
				}
			}
		}
	}
}

void Dataset::Threshold(unsigned char* dst, unsigned char channels, unsigned char threshold, unsigned short int width, unsigned short int height) {
	for (int a = 0; a < height; a++) {
		for (int b = 0; b < width; b++) {
			if ((int)dst[4 * (a * width + b) + 0] + (int)dst[4 * (a * width + b) + 1] + (int)dst[4 * (a * width + b) + 2] > threshold) {
				dst[4 * (a * width + b) + 0] = 255;
				dst[4 * (a * width + b) + 1] = 255;
				dst[4 * (a * width + b) + 2] = 255;
				dst[4 * (a * width + b) + 3] = 255;
			}
			else {
				dst[4 * (a * width + b) + 0] = 0;
				dst[4 * (a * width + b) + 1] = 0;
				dst[4 * (a * width + b) + 2] = 0;
				dst[4 * (a * width + b) + 3] = 0;
			}
		}
	}
}

void Dataset::SetEdges() {
	SDL_Surface* L_surf = L.GetSurface();
	SDL_Surface* R_surf = R.GetSurface();
	if (L_surf && R_surf) {
		SDL_Surface* L_edge_surf = SDL_CreateRGBSurfaceWithFormat(0, L_surf->w, L_surf->h, 32, SDL_PIXELFORMAT_RGBA32);
		SDL_Surface* R_edge_surf = SDL_CreateRGBSurfaceWithFormat(0, R_surf->w, R_surf->h, 32, SDL_PIXELFORMAT_RGBA32);
		if (L_edge_surf && R_edge_surf) {
			unsigned char* pixL = (unsigned char*)L_edge_surf->pixels;
			unsigned char* pixR = (unsigned char*)R_edge_surf->pixels;
			unsigned char* lp = (unsigned char*)L_surf->pixels;
			unsigned char* rp = (unsigned char*)R_surf->pixels;
			int w = L_edge_surf->w;
			int h = L_edge_surf->h;
			//for (int a = 0; a < h; a++) {
			//	for (int b = 0; b < w; b++) {
			//		pixels[4 * (a * w + b) + 0] = abs(lp[4 * (a * w + b) + 0] - rp[4 * (a * w + b) + 0]);
			//		pixels[4 * (a * w + b) + 1] = abs(lp[4 * (a * w + b) + 1] - rp[4 * (a * w + b) + 1]);
			//		pixels[4 * (a * w + b) + 2] = abs(lp[4 * (a * w + b) + 2] - rp[4 * (a * w + b) + 2]);
			//		pixels[4 * (a * w + b) + 3] = 255;
			//	}
			//}
			float kernel[9] = { -1.0f, -1.0f, -1.0f, -1.0f, 8.0f, -1.0f, -1.0f, -1.0f, -1.0f };
			//float kernel[9] = { 1.0f, 1.0f, 1.0f, 1.0f, -1.0f, 1.0f, 1.0f, 1.0f, 1.0f };
			
			Conv(pixL, lp, 4, kernel, 3, w, h);
			Conv(pixR, rp, 4, kernel, 3, w, h);
			Threshold(pixL, 4, 10, w, h);
			Threshold(pixR, 4, 10, w, h);
			//Compute(pixels, pixels, pixel_buf, 3, '+', w, h);
			
			L_edge.SetFromSurface(L_edge_surf, "L_edge");
			R_edge.SetFromSurface(R_edge_surf, "R_edge");
			//Surfaces given to Image, cleanup done there
		}
	}
}

int Dataset::MatchSquare(unsigned char* match_to, unsigned char* match_from, unsigned char channels, unsigned short int x_offset, unsigned short int y_offset, unsigned short int window_width, unsigned short int window_height, unsigned short int width, unsigned short int height, unsigned short int max_search, bool search_from_left, int move) {
	int best_match = 0;
	if (match_to && match_from && channels > 0 && width > 0 && height > 0 && window_width > 0 && window_height > 0) {
		int least_error = 255 * window_width * window_height;
		for (int g = 0; g < max_search * 2; g++) {
			int G = g;
			if (g >= max_search) {
				G = max_search - g;
			}
			if (search_from_left) {
				G = -G;
			}
			int error = 0;
			unsigned char ch = 0;//red channel
			for (int aa = 0; aa < window_width; aa++) {
				for (int bb = 0; bb < window_height; bb++) {
					int aq = y_offset + aa;
					int bq = x_offset + bb;
					int cq = x_offset + bb + G + move;
					if (aq >= 0 && aq < height && bq >= 0 && bq < width && cq >= 0 && cq < width) {
						error += abs((int)match_to[channels * (aq * width + bq) + ch] - (int)match_from[channels * (aq * width + cq) + ch]);
					}
					else {
						error += 128;
					}
				}
			}
			if (error < least_error) {
				best_match = G;
				least_error = error;
			}
		}
	}
	return best_match;
}

void Dataset::Disp() {
	L.Disp(0, 0, 192 * 2, 108 * 2);
	R.Disp(192 * 2, 0, 192 * 2, 108 * 2);
	L_edge.Disp(0, 108 * 2, 192 * 4, 108 * 4);
	R_edge.Disp(movx * movfactor, 108 * 2, 192 * 4, 108 * 4);
}

void Dataset::Cleanup() {
	L.Cleanup();
	R.Cleanup();
	L_edge.Cleanup();
	R_edge.Cleanup();
	name = "";
}