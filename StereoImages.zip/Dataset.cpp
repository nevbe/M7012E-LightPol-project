#include "Dataset.h"
#include <cmath>

void Dataset::Load(std::string dataset_name) {
	std::string name = dataset_name;
	dataset_name = "data/" + name + "/";
	L.Load(dataset_name + "im0.png");
	R.Load(dataset_name + "im1.png");
	SetDepth();
}

void Dataset::Conv(unsigned char* dst, unsigned char* src, unsigned char channels, float* kernel, unsigned char kernelsize, unsigned short int width, unsigned short int height) {
	if (dst && src && kernel && kernelsize > 1 && width > 1 && height > 1 && channels > 0) {
		for (int ch = 0; ch < channels; ch++) {
			for (int a = 0; a < height; a++) {
				for (int b = 0; b < width; b++) {
					float val = 0;
					for (int aa = 0; aa < kernelsize; aa++) {
						for (int bb = 0; bb < kernelsize; bb++) {
							int aq = a + aa - (kernelsize - 1) / 2;
							int bq = b + bb - (kernelsize - 1) / 2;
							if (aq >= 0 && aq < height && bq >= 0 && bq < width) {
								val += kernel[aa * kernelsize + bb] * (float)src[channels * (aq * width + bq) + ch];
							}
						}
					}
					val = val / kernelsize / kernelsize;
					if (val > 255) {
						val = 255;
					}
					if (val < 0) {
						val = 0;
					}
					dst[channels * (a * width + b) + ch] = val;
				}
			}
		}
	}
}

void Dataset::Compute(unsigned char* dst, unsigned char* src1, unsigned char* src2, unsigned char channels, char operation, unsigned short int width, unsigned short int height) {
	if (dst && src1 && src2 && channels > 0 && width > 0 && height > 0) {
		if (operation == '+') {
			for (int ch = 0; ch < channels; ch++) {
				for (int a = 0; a < height; a++) {
					for (int b = 0; b < width; b++) {
						int val = (int)src1[channels * (a * width + b) + ch] + (int)src2[channels * (a * width + b) + ch];
						if (val > 255) {
							val = 255;
						}
						dst[channels * (a * width + b) + ch] = val;
					}
				}
			}
		}
		else if (operation == '-') {
			for (int ch = 0; ch < channels; ch++) {
				for (int a = 0; a < height; a++) {
					for (int b = 0; b < width; b++) {
						int val = (int)src1[channels * (a * width + b) + ch] - (int)src2[channels * (a * width + b) + ch];
						if (val < 0) {
							val = 0;
						}
						dst[channels * (a * width + b) + ch] = val;
					}
				}
			}
		}
		else if (operation == '*') {
			for (int ch = 0; ch < channels; ch++) {
				for (int a = 0; a < height; a++) {
					for (int b = 0; b < width; b++) {
						int val = (int)src1[channels * (a * width + b) + ch] * (int)src2[channels * (a * width + b) + ch];
						if (val > 255) {
							val = 255;
						}
						dst[channels * (a * width + b) + ch] = val;
					}
				}
			}
		}
		else if (operation == '/') {
			for (int ch = 0; ch < channels; ch++) {
				for (int a = 0; a < height; a++) {
					for (int b = 0; b < width; b++) {
						float val = (float)src1[channels * (a * width + b) + ch] * (float)src2[channels * (a * width + b) + ch];
						//no failchecking needed
						dst[channels * (a * width + b) + ch] = val;
					}
				}
			}
		}
	}
}

void Dataset::Threshold(unsigned char* dst, unsigned char channels, unsigned char threshold, unsigned short int width, unsigned short int height) {
	for (int a = 0; a < height; a++) {
		for (int b = 0; b < width; b++) {
			dst[4 * (a * width + b) + 3] = 255;
			if ((int)dst[4 * (a * width + b) + 0] + (int)dst[4 * (a * width + b) + 1] + (int)dst[4 * (a * width + b) + 2] > threshold) {
				dst[4 * (a * width + b) + 0] = 255;
				dst[4 * (a * width + b) + 1] = 255;
				dst[4 * (a * width + b) + 2] = 255;
			}
			else {
				dst[4 * (a * width + b) + 0] = 0;
				dst[4 * (a * width + b) + 1] = 0;
				dst[4 * (a * width + b) + 2] = 0;
			}
		}
	}
}

void Dataset::SetDepth() {
	SDL_Surface* L_surf = L.GetSurface();
	SDL_Surface* R_surf = R.GetSurface();
	if (L_surf && R_surf) {
		SDL_Surface* depth_surf = SDL_CreateRGBSurfaceWithFormat(0, L_surf->w, L_surf->h, 32, SDL_PIXELFORMAT_RGBA32);
		if (depth_surf) {
			unsigned char* pixels = (unsigned char*)depth_surf->pixels;
			unsigned char* lp = (unsigned char*)L_surf->pixels;
			unsigned char* rp = (unsigned char*)R_surf->pixels;
			int w = depth_surf->w;
			int h = depth_surf->h;
			//for (int a = 0; a < h; a++) {
			//	for (int b = 0; b < w; b++) {
			//		pixels[4 * (a * w + b) + 0] = abs(lp[4 * (a * w + b) + 0] - rp[4 * (a * w + b) + 0]);
			//		pixels[4 * (a * w + b) + 1] = abs(lp[4 * (a * w + b) + 1] - rp[4 * (a * w + b) + 1]);
			//		pixels[4 * (a * w + b) + 2] = abs(lp[4 * (a * w + b) + 2] - rp[4 * (a * w + b) + 2]);
			//		pixels[4 * (a * w + b) + 3] = 255;
			//	}
			//}
			float kernel[9] = { -1.0f, -1.0f, -1.0f, -1.0f, 8.0f, -1.0f, -1.0f, -1.0f, -1.0f };
			//float kernel[9] = { 1.0f, 1.0f, 1.0f, 1.0f, -1.0f, 1.0f, 1.0f, 1.0f, 1.0f };
			unsigned char* pixel_buf = (unsigned char*)malloc(w * h * 4);
			Conv(pixels, lp, 4, kernel, 3, w, h);
			Conv(pixel_buf, rp, 4, kernel, 3, w, h);
			Threshold(pixels, 4, 10, w, h);
			Threshold(pixel_buf, 4, 10, w, h);
			Compute(pixels, pixels, pixel_buf, 3, '+', w, h);
			free(pixel_buf);
			depth.SetFromSurface(depth_surf, "depth");
			depth_surf = nullptr;//given to Image, cleanup done there
		}
	}
}

void Dataset::Disp() {
	L.Disp(0, 0, 192 * 2, 108 * 2);
	R.Disp(192 * 2, 0, 192 * 2, 108 * 2);
	depth.Disp(0, 108 * 2, 192 * 4, 108 * 4);
}

void Dataset::Cleanup() {
	L.Cleanup();
	R.Cleanup();
	depth.Cleanup();
	name = "";
}