#pragma once
#include "Image.h"
#include <vector>

class Dataset {
public:
	Dataset() { }
	~Dataset() {
		Cleanup();
	}
	void Load(std::string dataset_name);
	void Conv(unsigned char* dst, unsigned char* src, unsigned char channels, float* kernel, unsigned char kernelsize, unsigned short int width, unsigned short int height);
	void Compute(unsigned char* dst, unsigned char* src1, unsigned char* src2, unsigned char channels, char operation, unsigned short int width, unsigned short int height);
	void Threshold(unsigned char* dst, unsigned char channels, unsigned char threshold, unsigned short int width, unsigned short int height);
	void SetEdges();
	int MatchSquare(unsigned char* match_to, unsigned char* match_from, unsigned char channels, unsigned short int x_offset, unsigned short int y_offset, unsigned short int window_width, unsigned short int window_height, unsigned short int width, unsigned short int height, unsigned short int max_search, bool search_from_left, int move);
	Image& GetL_edge() {
		return L_edge;
	}
	Image& GetR_edge() {
		return R_edge;
	}
	void Disp();
	void Cleanup();
	int movx = 0;
	float movfactor = 0.4f;
private:
	Image L;
	Image R;
	Image L_edge;
	Image R_edge;
	std::string name = "";
};

