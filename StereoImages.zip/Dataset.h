#pragma once
#include "Image.h"
#include <vector>

class Dataset {
public:
	Dataset() { }
	~Dataset() {
		Cleanup();
	}
	void Load(std::string dataset_name);
	void Conv(unsigned char* dst, unsigned char* src, unsigned char channels, float* kernel, unsigned char kernelsize, unsigned short int width, unsigned short int height);
	void Compute(unsigned char* dst, unsigned char* src1, unsigned char* src2, unsigned char channels, char operation, unsigned short int width, unsigned short int height);
	void Threshold(unsigned char* dst, unsigned char channels, unsigned char threshold, unsigned short int width, unsigned short int height);
	void SetDepth();
	Image& GetDepth() {
		return depth;
	}
	void Disp();
	void Cleanup();
private:
	Image L;
	Image R;
	Image depth;
	std::string name = "";
};

