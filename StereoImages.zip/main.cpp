#define SDL_MAIN_HANDLED
#include <SDL.h>
#include <SDL_image.h>
#include <Windows.h>//key presses

#include "Dataset.h"//Image.h included

SDL_Renderer* renderer;
SDL_Window* window;
SDL_Event mainevent;
bool running = true;
Dataset data;

int screenw = 1080;
int screenh = 640;

int my = 0;
int mx = 0;

bool Pressed(unsigned char key) {
	return GetAsyncKeyState(key);//windows-specific, change if on linux
}

void InitSDL() {
	SDL_Init(SDL_INIT_EVERYTHING);
	IMG_Init(IMG_INIT_PNG | IMG_INIT_JPG);
	window = SDL_CreateWindow("Test", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, screenw, screenh, 0);
	if (window) {
		renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	}
}

void MainLoop() {
	while (running) {
		SDL_RenderClear(renderer);

		SDL_PollEvent(&mainevent);
		SDL_GetMouseState(&mx, &my);

		if (Pressed(VK_TAB)) {
			running = false;
		}

		data.Disp();
		if (Pressed(0x01)) {//mouse button down
			SDL_Texture* texture = data.GetDepth().GetTexture();
			if (texture && mx >= 0 && mx < 192 * 4 && my >= 108 * 2 && my < screenh) {
				SDL_Rect disprect;
				disprect.x = 192 * 4;
				disprect.y = 0;
				disprect.w = screenw - 192 * 4;
				disprect.h = 108 * 6;
				int xpos = mx * screenw / (192 * 4) * screenw / (192 * 4);
				int ypos = (my - 108 * 2) * screenh / (108 * 6);
				SDL_Rect srcrect;
				srcrect.x = xpos;
				srcrect.y = ypos;
				srcrect.w = disprect.w;
				srcrect.h = disprect.h;
				SDL_RenderCopy(renderer, texture, &srcrect, &disprect);
			}
		}

		SDL_RenderPresent(renderer);
	}
}

int main() {
	InitSDL();

	data.Load("artroom1");

	MainLoop();

	data.Cleanup();

	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);

	IMG_Quit();
	SDL_Quit();
}