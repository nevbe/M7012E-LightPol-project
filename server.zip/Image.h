#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <string>

class Image {
public:
	Image() { }
	~Image() {
		Cleanup();
	}
	SDL_Surface* GetSurface() {
		return surf;
	}
	SDL_Texture* GetTexture() {
		return texture;
	}
	void Load(std::string filename);//png or jpg
	void SetFromSurface(SDL_Surface* set_surf = nullptr, std::string set_name = "set");
	void Disp(int x, int y, int w, int h);
	void Cleanup();
private:
	SDL_Texture* texture = nullptr;
	SDL_Surface* surf = nullptr;
	SDL_Rect disprect = { 0 };
	std::string name = "";
};

