#include "Server.h"
#include <thread>
#include <iostream>
#include <fstream>
#include "Datapoint.h"

extern Datapoint sensor;

void Server::StartServer() {
    if (SDLNet_ResolveHost(&ip, NULL, port) < 0) {
        return;
    }
    std::cout << SDLNet_ResolveIP(&ip) << "\n";
    //system("pause>nul");
    listening_socket = SDLNet_TCP_Open(&ip);
    if (!listening_socket) {
        return;
    }
    std::thread listen_thread(&Server::Listen, this);//Listen on separate thread
    listen_thread.detach();
    command_mut.lock();
    std::cout << "Server started\n";
    command_mut.unlock();
}

void Server::StopServer() {
    listen = false;
    client_mut.lock();
    for (int a = 0; a < client.size(); a++) {
        if (client[a]) {
            SDLNet_TCP_Close(client[a]->sock);
            SDLNet_FreeSocketSet(client[a]->set);
            delete client[a];
            client[a] = nullptr;
        }
    }
    client.clear();
    client_mut.unlock();

    command_mut.lock();
    std::cout << "Server stopped\n";
    command_mut.unlock();
}

void Server::Receive() {
    client_mut.lock();
    for (int a = 0; a < client.size(); a++) {
        if (SDLNet_CheckSockets(client[a]->set, 0) > 0) {
            for (int b = 0; b < maxdata; b++) {
                client[a]->data[b] = 0;
            }
            if (SDLNet_TCP_Recv(client[a]->sock, (void*)client[a]->data, maxdata) > 0) {
                //Command(client[a]->data, client[a]);//FEL
                //std::cout << client[a]->data << "\n";
                //std::cout << "AAA" << "\n";
                std::thread command_thread(&Server::Command, this, client[a]->data, client[a]);
                command_thread.detach();
                client[a]->timeout = 0;
            }
        }
        else {
            client[a]->timeout++;
            if (client[a]->timeout == maxtime / 2) {
                std::string msg = "hello\n";
                SDLNet_TCP_Send(client[a]->sock, msg.c_str(), msg.size());
            }
            else if (client[a]->timeout >= maxtime) {
                DropConnection(client[a]);
                a = client.size() + 1;//break the loop
            }
        }
    }
    client_mut.unlock();
}

void Server::Listen() {
    listen = true;
    while (listen) {
        TCPsocket new_socket = SDLNet_TCP_Accept(listening_socket);
        if (new_socket) {
            client_mut.lock();
            if (listen) {
                Client* new_client = new Client;
                new_client->set = SDLNet_AllocSocketSet(1);
                SDLNet_TCP_AddSocket(new_client->set, new_socket);
                new_client->sock = new_socket;

                command_mut.lock();
                std::cout << "new connection! (" << client.size() + 1 << " total)\n";
                command_mut.unlock();

                std::string msg = "send help\n";
                SDLNet_TCP_Send(new_client->sock, msg.c_str(), msg.size());
                new_client->auth = UNAUTH_FRIEND;

                client.push_back(new_client);
            }
            else {
                SDLNet_TCP_Close(new_socket);
            }
            client_mut.unlock();
        }
    }
    SDLNet_TCP_Close(listening_socket);
    listening_socket = nullptr;
}

void Server::Command(char* data, Client* which_client) {
    command_mut.lock();

    std::string command((char*)data);
    //std::cout << command << "\n";//instead do fun stuff
    
    command_mut.unlock();

    client_mut.lock();

    if (!FindClient(which_client)) {
        which_client = nullptr;
    }

    if (!which_client) {
        client_mut.unlock();
        return;
    }

    if (which_client->auth > UNKNOWN_FRIEND) {
        //ok
        if (which_client->receiving > 0) {
            if (which_client->receiving >= command.size()) {
                which_client->data_buf += command;
                which_client->receiving -= command.size();
                command = "";
            }
            else {
                which_client->data_buf += command.substr(0, which_client->receiving);
                which_client->receiving = 0;
                command = command.substr(which_client->receiving, command.size() - which_client->receiving);
            }
            if (which_client->receiving == 0) {
                //finished
                if (which_client->task.size() >= 9) {
                    if (which_client->task.find("img ") == 0) {
                        int pos = which_client->task.find(".jpg", 4);
                        if (pos == which_client->task.size() - 4) {
                            std::string imgname = which_client->task.substr(4, pos - 4);

                            //check if name is ok
                            bool name_ok = true;
                            for (int a = 0; a < imgname.size(); a++) {
                                if ((imgname[a] >= 'a' && imgname[a] <= 'z') || (imgname[a] >= 'A' && imgname[a] <= 'Z') || (imgname[a] >= '0' && imgname[a] <= '9')) {
                                    //ok
                                }
                                else {
                                    name_ok = false;
                                }
                            }
                            if (name_ok) {
                                imgname = "dump/" + imgname + ".jpg";
                                std::ofstream file;
                                file.open(imgname.c_str());
                                if (file.is_open()) {
                                    file.write(which_client->data_buf.c_str(), which_client->data_buf.size());
                                    file.close();
                                }
                                command_mut.lock();
                                std::cout << "made jpg - '" << imgname << "'\n";
                                command_mut.unlock();

                                std::string msg = "image received " + imgname + "\n";
                                SDLNet_TCP_Send(which_client->sock, msg.c_str(), msg.size());
                            }
                            else {
                                command_mut.lock();
                                std::cout << "name is weird - '" << imgname << "'\n";
                                command_mut.unlock();
                            }
                        }
                    }
                }
            }
        }
        if (which_client->receiving == 0) {
            which_client->data_buf = "";
            which_client->task = "";
        }
        int pos = command.find_first_of('\n');
        if (pos < command.size() - 1) {
            which_client->data_buf += command.substr(pos, command.size() - pos);
            command = command.substr(0, pos);
        }
    }
    else if (which_client->auth == UNAUTH_FRIEND) {
        std::string comp = "no help";
        if (command.find(comp) == 0) {//auth ok
            which_client->auth = UNKNOWN_FRIEND;
            std::string msg = "wtf\n";
            SDLNet_TCP_Send(which_client->sock, msg.c_str(), msg.size());
            command_mut.lock();
            std::cout << "auth ok\n";
            command_mut.unlock();
        }
        else {
            DropConnection(which_client);
        }
    }

    if (which_client->auth < UNKNOWN_FRIEND) {//only let authorized connections make commands
        client_mut.unlock();
        return;
    }

    client_mut.unlock();

    std::string comp;

    comp = "meas";
    if (command.find(comp) == 0) {
        client_mut.lock();
        bool found = FindClient(which_client);
        if (found && which_client->auth == SENSOR_FRIEND) {
            //ok
        }
        else {
            found = false;
        }
        client_mut.unlock();
        if (found) {
            command_mut.lock();
            std::cout << "receiving measurements";
            command_mut.unlock();
            int pos;
            for (int a = 0; a < 3; a++) {
                if (command.size() > comp.size() + 1) {
                    command = command.substr(comp.size() + 1, command.size() - (comp.size() + 1));
                    pos = command.find_first_of(" \n");
                    if (pos > 0) {
                        comp = command.substr(0, pos);
                        sensor.sensor_val[a] = atoi(comp.c_str());
                        command_mut.lock();
                        std::cout << " (" << a << ")'" << sensor.sensor_val[a] << "'";
                        command_mut.unlock();
                    }
                    else {
                        a = 3;//breaks loop
                    }
                }
                else {
                    a = 3;//breaks loop
                }
            }
            command_mut.lock();
            std::cout << "\n";
            command_mut.unlock();
        }

        goto END_COMP;
    }

    comp = "sensor friend";
    if (command.find(comp) == 0) {

        client_mut.lock();
        bool found = FindClient(which_client);
        if (found && which_client->auth >= UNKNOWN_FRIEND) {
            which_client->auth = SENSOR_FRIEND;
        }
        client_mut.unlock();

        command_mut.lock();
        std::cout << "client is a sensor\n";
        command_mut.unlock();
        
        goto END_COMP;
    }

    comp = "phone friend";
    if (command.find(comp) == 0) {

        client_mut.lock();
        bool found = FindClient(which_client);
        if (found && which_client->auth >= UNKNOWN_FRIEND) {
            which_client->auth = PHONE_FRIEND;
        }
        client_mut.unlock();

        command_mut.lock();
        std::cout << "client is a phone\n";
        command_mut.unlock();

        goto END_COMP;
    }

    comp = "img ";
    if (command.find(comp) == 0) {
        client_mut.lock();
        bool found = FindClient(which_client);
        if (found && which_client->auth == PHONE_FRIEND) {
            //ok
        }
        else {
            found = false;
        }
        client_mut.unlock();
        if (found) {
            int pos = command.find_first_of(';');
            if (pos > 0) {
                int pos2 = command.size();
                if (pos2 - pos > 1) {
                    int bytes = atoi(command.substr(pos + 1, pos2 - (pos + 1)).c_str());
                    if (bytes > 0 && bytes < 25000000) {//25 megabytes max
                        client_mut.lock();
                        found = FindClient(which_client);
                        if (found) {//and authenticated?
                            which_client->receiving = bytes;
                            which_client->task = command.substr(0, pos);
                            command_mut.lock();
                            std::cout << "image being received\n";
                            command_mut.unlock();
                        }
                        client_mut.unlock();
                    }
                }
            }
        }
    }

    END_COMP:
    return;
}

bool Server::FindClient(Client* which_client) {
    bool found = false;
    if (which_client) {
        for (int a = 0; a < client.size(); a++) {
            if (client[a] == which_client) {
                found = true;
                a = client.size();
            }
        }
    }
    return found;
}

void Server::DropConnection(Client* which_client) {
    if (which_client) {
        for (int a = 0; a < client.size(); a++) {
            if (client[a] == which_client) {
                client[a] = nullptr;
                client.erase(client.begin() + a);

                SDLNet_TCP_Close(which_client->sock);
                SDLNet_FreeSocketSet(which_client->set);
                delete which_client;

                command_mut.lock();
                std::cout << "connection " << a << " dropped! (" << client.size() << " remaining)\n";
                command_mut.unlock();

                return;
            }
        }
    }
}
