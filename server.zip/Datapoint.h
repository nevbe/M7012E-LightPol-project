#pragma once
class Datapoint {
public:
	int sensor_val[3] = { 0 };
};

